
import styles from '../styles/Animations.module.css';

const Footer = () => (
  <footer className={styles.fadeIn}>
    <p>© 2024 Iladary. All rights reserved.</p>
  </footer>
);

export default Footer;
