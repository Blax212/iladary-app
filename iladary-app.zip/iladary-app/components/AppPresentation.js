
import styles from '../styles/Animations.module.css';

const AppPresentation = () => (
  <section className={styles.fadeIn}>
    <h2>About Iladary</h2>
    <p>Introducing the features and benefits of our app.</p>
  </section>
);

export default AppPresentation;
