
import styles from '../styles/Animations.module.css';

const DownloadApp = () => (
  <section className={styles.fadeIn}>
    <h2>Download Our App</h2>
    <a href="https://play.google.com/store/apps/details?id=com.iladary">Download on Google Play</a>
    <a href="https://apps.apple.com/us/app/iladary/id123456789">Download on App Store</a>
  </section>
);

export default DownloadApp;
