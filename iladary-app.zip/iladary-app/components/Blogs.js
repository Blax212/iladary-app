
import styles from '../styles/Animations.module.css';

const Blogs = () => (
  <section className={styles.fadeIn}>
    <h2>Our Blog</h2>
    <p>Latest news and articles about Iladary.</p>
  </section>
);

export default Blogs;
