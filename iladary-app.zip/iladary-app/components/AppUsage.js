
import styles from '../styles/Animations.module.css';

const AppUsage = () => (
  <section className={styles.fadeIn}>
    <h2>How to Use Iladary</h2>
    <p>Step-by-step guide on how to use the app.</p>
    <img src="/images/app-screenshot.png" alt="App Screenshot" className={styles.slideUp} />
  </section>
);

export default AppUsage;
