
import Link from 'next/link';
import styles from '../styles/Animations.module.css';

const Header = () => (
  <header className={styles.fadeIn}>
    <nav>
      <ul>
        <li><Link href="/">Home</Link></li>
        <li><Link href="/app">App</Link></li>
        <li><Link href="/blogs">Blogs</Link></li>
        <li><Link href="/contact">Contact Us</Link></li>
      </ul>
    </nav>
  </header>
);

export default Header;
