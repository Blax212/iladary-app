
import Header from '../components/Header';
import Footer from '../components/Footer';
import AppUsage from '../components/AppUsage';
import AppPresentation from '../components/AppPresentation';
import DownloadApp from '../components/DownloadApp';

export default function Home() {
  return (
    <div>
      <Header />
      <main>
        <AppPresentation />
        <AppUsage />
        <DownloadApp />
      </main>
      <Footer />
    </div>
  );
}
