
import Header from '../components/Header';
import Footer from '../components/Footer';
import Blogs from '../components/Blogs';

export default function BlogsPage() {
  return (
    <div>
      <Header />
      <main>
        <Blogs />
      </main>
      <Footer />
    </div>
  );
}
