
import Header from '../components/Header';
import Footer from '../components/Footer';
import AppPresentation from '../components/AppPresentation';
import AppUsage from '../components/AppUsage';

export default function AppPage() {
  return (
    <div>
      <Header />
      <main>
        <AppPresentation />
        <AppUsage />
      </main>
      <Footer />
    </div>
  );
}
